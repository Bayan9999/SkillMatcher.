import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { calculateSkillMatch } from '@/lib/utils'

interface JobCardProps {
  job: {
    id: string
    title: string
    company: string
    description: string
    requiredSkills: string[]
    location: string
    type: string
    salary?: string
    postedDate: string
  }
  userSkills?: string[]
}

export function JobCard({ job, userSkills = [] }: JobCardProps) {
  const matchPercentage = userSkills.length > 0 
    ? calculateSkillMatch(job.requiredSkills, userSkills) 
    : 0

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl mb-1">{job.title}</CardTitle>
            <CardDescription className="text-base">{job.company}</CardDescription>
          </div>
          {matchPercentage > 0 && (
            <Badge variant={matchPercentage > 70 ? "default" : "secondary"}>
              {matchPercentage}% match
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
          {job.description}
        </p>
        
        <div className="space-y-2">
          <div className="flex flex-wrap gap-2">
            {job.requiredSkills.slice(0, 4).map((skill) => (
              <Badge key={skill} variant="outline" className="text-xs">
                {skill}
              </Badge>
            ))}
            {job.requiredSkills.length > 4 && (
              <Badge variant="outline" className="text-xs">
                +{job.requiredSkills.length - 4} more
              </Badge>
            )}
          </div>
          
          <div className="flex justify-between items-center text-sm text-muted-foreground">
            <span>{job.location}</span>
            <span>{job.type}</span>
          </div>
          
          {job.salary && (
            <p className="text-sm font-medium">{job.salary}</p>
          )}
        </div>
        
        <Link href={`/jobs/${job.id}`}>
          <Button className="w-full mt-4">View Details</Button>
        </Link>
      </CardContent>
    </Card>
  )
}
