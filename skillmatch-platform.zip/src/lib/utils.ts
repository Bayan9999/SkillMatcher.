import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Types for our platform
export interface Job {
  id: string
  title: string
  description: string
  company: string
  requiredSkills: string[]
  location: string
  type: 'full-time' | 'part-time' | 'contract' | 'freelance'
  salary?: string
  postedDate: string
}

export interface User {
  id: string
  name: string
  email: string
  microSkills: string[]
}

// Helper function to filter jobs by matching micro skills
export function filterJobsBySkills(jobs: Job[], userSkills: string[]): Job[] {
  if (!jobs || !userSkills) return []
  
  return jobs.filter(job => {
    const jobSkills = job.requiredSkills.map(skill => skill.toLowerCase())
    const userSkillsLower = userSkills.map(skill => skill.toLowerCase())
    
    // Check if any user skill matches any job skill
    return jobSkills.some(jobSkill => 
      userSkillsLower.some(userSkill => 
        jobSkill.includes(userSkill) || userSkill.includes(jobSkill)
      )
    )
  })
}

// Helper function to calculate skill match percentage
export function calculateSkillMatch(jobSkills: string[], userSkills: string[]): number {
  if (!jobSkills || !userSkills || jobSkills.length === 0) return 0
  
  const jobSkillsLower = jobSkills.map(skill => skill.toLowerCase())
  const userSkillsLower = userSkills.map(skill => skill.toLowerCase())
  
  const matchedSkills = jobSkillsLower.filter(jobSkill =>
    userSkillsLower.some(userSkill => 
      jobSkill.includes(userSkill) || userSkill.includes(jobSkill)
    )
  )
  
  return Math.round((matchedSkills.length / jobSkills.length) * 100)
}

// Sample data for development
export const sampleJobs: Job[] = [
  {
    id: '1',
    title: 'Frontend Developer',
    description: 'Looking for a frontend developer with React and TypeScript experience to build modern web applications.',
    company: 'TechCorp Inc.',
    requiredSkills: ['React', 'TypeScript', 'Tailwind CSS', 'Next.js'],
    location: 'Remote',
    type: 'full-time',
    salary: '$80,000 - $120,000',
    postedDate: '2024-01-15'
  },
  {
    id: '2',
    title: 'UI/UX Designer',
    description: 'Seeking a creative UI/UX designer to create beautiful and functional user interfaces.',
    company: 'Design Studio',
    requiredSkills: ['Figma', 'UI Design', 'User Research', 'Prototyping'],
    location: 'San Francisco, CA',
    type: 'contract',
    salary: '$60 - $80/hour',
    postedDate: '2024-01-14'
  },
  {
    id: '3',
    title: 'Full Stack Developer',
    description: 'Join our team to work on both frontend and backend development using modern technologies.',
    company: 'StartupXYZ',
    requiredSkills: ['Node.js', 'React', 'MongoDB', 'GraphQL'],
    location: 'New York, NY',
    type: 'full-time',
    salary: '$90,000 - $130,000',
    postedDate: '2024-01-13'
  },
  {
    id: '4',
    title: 'Data Analyst',
    description: 'Analyze data and create insights to drive business decisions.',
    company: 'Analytics Pro',
    requiredSkills: ['Python', 'SQL', 'Data Visualization', 'Statistics'],
    location: 'Remote',
    type: 'part-time',
    salary: '$40 - $60/hour',
    postedDate: '2024-01-12'
  },
  {
    id: '5',
    title: 'Mobile App Developer',
    description: 'Develop cross-platform mobile applications using React Native.',
    company: 'MobileFirst',
    requiredSkills: ['React Native', 'JavaScript', 'Mobile UI', 'API Integration'],
    location: 'Austin, TX',
    type: 'freelance',
    salary: '$70 - $100/hour',
    postedDate: '2024-01-11'
  }
]

export const sampleUser: User = {
  id: '1',
  name: 'John Doe',
  email: 'john@example.com',
  microSkills: ['React', 'TypeScript', 'Node.js', 'UI Design', 'JavaScript']
}
