import { NextRequest, NextResponse } from 'next/server'
import { sampleJobs } from '@/lib/utils'

export async function GET(request: NextRequest) {
  try {
    // Simulate fetching jobs from a database
    const jobs = sampleJobs
    
    return NextResponse.json({
      success: true,
      data: jobs,
      count: jobs.length
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch jobs' },
      { status: 500 }
    )
  }
}
