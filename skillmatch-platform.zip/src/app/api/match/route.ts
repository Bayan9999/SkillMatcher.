import { NextRequest, NextResponse } from 'next/server'
import { sampleJobs, filterJobsBySkills } from '@/lib/utils'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userSkills } = body

    if (!userSkills || !Array.isArray(userSkills)) {
      return NextResponse.json(
        { success: false, error: 'User skills are required and must be an array' },
        { status: 400 }
      )
    }

    // Filter jobs based on user skills
    const matchedJobs = filterJobsBySkills(sampleJobs, userSkills)
    
    return NextResponse.json({
      success: true,
      data: matchedJobs,
      count: matchedJobs.length,
      userSkills
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to match jobs' },
      { status: 500 }
    )
  }
}
